//Program to demonstrate nested try catch - Driver Class
package com.tnsif.dayeleven.nestedtrycatch;

public class NestedTryCatchDemo {
	public static void main(String[] a) {
		
		NestedTryCatch.check();
	}
	
}
