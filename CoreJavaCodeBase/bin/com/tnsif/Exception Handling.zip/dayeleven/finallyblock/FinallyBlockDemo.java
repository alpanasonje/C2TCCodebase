//program to demonstrate finally block

package com.tnsif.dayeleven.finallyblock;

public class FinallyBlockDemo {

	public static void main(String[] args) {
		FinallyBlockExOne.divide(12,3);
		FinallyBlockExOne.divide(2,0);
	}

}
